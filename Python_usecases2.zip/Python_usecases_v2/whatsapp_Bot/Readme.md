# Whatsapp Bot
## Perform Operation like
1. Put your details
2. connect with internet
3. Pass your message

# To run app
- Create virtual Environment
- Install requirements
`pip install requirements.txt`
- run app
`python main.py`
