# Script Title
#### Script to reduce the size of image file using the openCV library of python.

### Prerequisites
openCV library

`pip install opencv-python`

### How to run the script
- Add the image in jpg format with name as 'input.jpg' in this folder.
- Run reduce_image_size.py script.
- resized output image will be generated in this folder.
