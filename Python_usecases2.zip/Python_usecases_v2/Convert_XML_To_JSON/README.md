# Converter

Convert XML to JSON

### prerequisite
- you need to install below library using pip
- $ pip install xmltodict
 
### Description
- It coverts any input.xml file into output.json.

### How to run the script

- First rename your file to input.xml 
- Execute `python3 converter.py`
- The Output will be shown below as output.json

