# Recursive Password Generator
<!--Remove the below lines and add yours -->
Generates a random password with the length specified using recursivity

### Prerequisites
<!--Remove the below lines and add yours -->
None

### How to run the script
<!--Remove the below lines and add yours -->
Execute `python3 generator.py`

