import webbrowser

webbrowser.open("https://www.youtube.com/watch?v=7wtfhZwyrcc")