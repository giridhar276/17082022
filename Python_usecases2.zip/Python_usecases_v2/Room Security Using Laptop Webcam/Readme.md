# Room Security Using Laptop Webcam



# Dependencies:

*Open CV*
```python

pip install opencv-python
```
*Flask*
```python

pip install flask
```
# Run:

*Run this Script to run a local server*
```python

python main.py
```

*Live Stream*
```
http://0.0.0.0:5000
```





