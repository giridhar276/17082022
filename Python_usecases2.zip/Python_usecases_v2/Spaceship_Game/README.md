# SPACESHIP GAME

- The python script makes use of Pygame, a popular GUI module, to develop an interactive multiplayer Spaceship Game.
- The 2 players compete to aim bullets at each other and the first player to lose their health, loses.

## Requirements:

All the packages essential for running the script can be installed as follows:

``` sh
$ pip install -r requirements.txt
```


