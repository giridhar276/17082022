
## Image To Speech Functionalities : 🚀

- The script converts an image to text and speech files
- At the end the script asks whether to save or delete files 

## Image To Speech Instructions: 👨🏻‍💻

### Step 1:

    Open Termnial 💻

### Step 2:

    Locate to the directory where python file is located 📂

### Step 3:

    Run the command: python image_to_speech.py/python3 image_to_speech.py 🧐

### Step 4:

    Sit back and Relax. Let the Script do the Job. ☕

### Requirements

    - pytesseract
    - PIL
    - gTTS
    - os

