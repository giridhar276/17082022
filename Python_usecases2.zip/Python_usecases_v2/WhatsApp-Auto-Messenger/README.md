<h1 align="center">WhatsApp Auto Messenger</h1>
Send and schedule a message in WhatsApp by only seven lines of Python Script. 

---------------------------------------------------------------------

## Modules Used
- pywhatkit

pip install [requirements.txt]

## How it works
- First login your WhatsApp web version by scanning QR Code.

- By just providing the string format (receiver(recipient) Phone number with country code, message you want to send to receiver, schedule time in 24hrs format).

- Then on scheduled time it opens on WhatsApp web on your default browser and sends your message to the receiver phone number.

