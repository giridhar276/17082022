# USSD
Unstructured Supplementary Service Data (USSD), sometimes referred to as "Quick Codes" or "Feature codes", is a communications protocol used by GSM cellular telephones to communicate with the mobile network operator's computers. USSD can be used for WAP browsing, prepaid callback service, mobile-money services, location-based content services, menu-based information services, and as part of configuring the phone on the network 

MODULES REQUIRED
1. random 
2.time
3. sys 

EXECUTION PROCESS
1. fork code
2. git clone SSH 
3. open on device using a python IDE 
4. run the script 


