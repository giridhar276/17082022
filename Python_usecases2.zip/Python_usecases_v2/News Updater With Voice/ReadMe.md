


## Get News API key From HERE:
[NewsAPI](https://newsapi.org/)

## Add Your API Key:

```
newsapi = NewsApiClient(api_key='Add it Here')

```


## Dependencies:

*Newsapi*
```python

pip install newsapi
```
*pyttsx3*
```python

pip install pyttsx3
```
*pyaudio*
```python
pip install pyaudio
```


