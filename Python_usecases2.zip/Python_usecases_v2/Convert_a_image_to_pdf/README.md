    
# Convert an Image to PDF
<!--Remove the below lines and add yours -->
The Python script enables the user to convert Images into PDF files. However, you must note that the script can only work well for JPG file formats. You can use the converter for revamping JPG images into PDF format.

### Requirements
<!--Remove the below lines and add yours -->
**img2pdf module**

The `img2pdf` is an external Python module which enables you to convert a JPG image into a PDF.

    pip install img2pdf

### How to run the script
<!--Remove the below lines and add yours -->
### Using Terminal

-   Add the image in the JPG format with name as 'input' in this folder.
-   Run converter_terminal.py script
-   Output PDF file will be generated in this folder



