

## Unzip File Functionalities : 🚀

- Upload the zip file which is to be unzipped
- Then the script will return all the unzipped files into the Unzip files folder

## Unzip File Instructions: 👨🏻‍💻

### Step 1:

    Open Termnial 💻

### Step 2:

    Locate to the directory where python file is located 📂

### Step 3:

    Run the command: python script.py/python3 script.py 🧐

### Step 4:

    Sit back and Relax. Let the Script do the Job. ☕

### Requirements

    - zipfile
    

