# Calculate Your Age!
<!--Remove the below lines and add yours -->
This script prints your age in three different ways : 
1. Years
2. Months
3. Days


## Prerequisites
<!--Remove the below lines and add yours -->
You only need Python to run this script. You can visit [here](https://www.python.org/downloads/) to download Python.


## How to run the script
<!--Remove the below lines and add yours -->
Running the script is really simple! Just open a terminal in the folder where your script is located and run the following command :

    `python calculate.py`


## Sample use of the script
<!--Remove the below lines and add yours -->
```
$ python calculate.py 
    input your name: XYZ
    input your age: 33 
    XYZ's age is 33 years or 406 months or 12328 days
```
