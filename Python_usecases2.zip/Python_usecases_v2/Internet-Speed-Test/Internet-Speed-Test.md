# Internet-Speed-Test

Step 1:

Install speedtest-cli package using pip 
    In CMD : pip install speedtest-cli

step 2:

After Installing speedtest-cli library 
    In CMD: speedtest-cli

And then You'll get the following information

Download Speed
Upload Speed
Ping