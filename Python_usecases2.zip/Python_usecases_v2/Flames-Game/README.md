# Flames Game

    *Requirements*
    Python
    Download it from: https://www.python.org/downloads/

    Run the file and give your input of both names and click "Flame" button.
    The replation will be displayed below the button.

    Thank you