# Hello

This script is a good way to show how the print function work and it's usually every programmer's first line of code. The print() function prints the specified message to the screen.

### Prerequisites

Python installed locally. Check [here](https://www.python.org/downloads/) to install depending on your OS

### How to run the script

```
python Hello.py
```

The final result will be printed on the screen as:

```
Hello Python World
```


