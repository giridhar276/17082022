# Racing Bar Chart Animation


## Packages Needed

**Make sure you are using a python virtual environment**

`pip install jupyterlab`

`pip install pandas`

`pip install requests`

OR

`pip install -r requirements.txt`


