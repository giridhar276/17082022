# Convert a json file into a csv
This script take a json file as input and generate a csv file in output.

### Prerequisites modules
* json
* Run `pip install json` to install required external modules.

### How to run the script
- Execute `python3 converter.py`
