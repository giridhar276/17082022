

Then insert your token at the top of the file.

Make sure you have discord.py installed:
```bash
pip install discord
```

Then just run the bot using python:
```bash
python bot.py
```
