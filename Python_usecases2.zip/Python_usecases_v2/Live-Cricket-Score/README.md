# Cricbuzz srapper

 This python script will scrap cricbuzz.com to get live scores of the matches.
 
## Setup

* Install the dependencies

    `pip install -r requirements.txt`
* Run the file

    `python live_score.py`


