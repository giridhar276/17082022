# Script Title
<!--Remove the below lines and add yours -->
A small python program that converts currency with live info

### Prerequisites
<!--Remove the below lines and add yours -->
- requests
- Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python cc.py


